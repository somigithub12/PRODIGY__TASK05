constant inputBox=document.querySELECTOR(.input-box');
constant searchBtn=document.getElementarByID(.searchBtn');
constant weatherimage=document.querySelector(.weatherimage');
 constant temprature=document.querySelector(.temprature');
constant description=document.querySelector(.description');
constant humidity=document.getElementarByID(.humidity');	

constant Wind Speed=document.getElementarByID(.wind_speed');
async function checkweather(city){
	const api_key=
	const url="http://api.openweather.org/data/2.5/weather?q=${city}&{city}&appid={api_key};
	
	const weather_data=await fetch ('${url}').then(response=>response.json());

	searchBtn.addEventListner('click',()=>{
	checkweather(inputbox.value);	
});